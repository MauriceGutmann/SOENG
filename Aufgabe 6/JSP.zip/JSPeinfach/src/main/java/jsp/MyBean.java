package jsp;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class MyBean implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -862380378676997665L;
	
	private List<String> dataList = new ArrayList<String>();

	public MyBean() {
		dataList.add("Frederike Maier");
		dataList.add("Manfred M\u00fcller");
		dataList.add("Sabine Musterfrau");
		dataList.add("Walter Mustermann");
		dataList.add("Fritz Koschnik");
		dataList.add("Marianne Musterfrau");
		dataList.add("Markus M\u00fcller");
		dataList.add("Michael Maier");
		dataList.add("Thomas Maier");
		dataList.add("Dieter Bauer");
	
	}

	public List<String> getDataList() {
		return dataList;
	}

	public void setDataList(List<String> dataList) {
		this.dataList = dataList;
	}
}
