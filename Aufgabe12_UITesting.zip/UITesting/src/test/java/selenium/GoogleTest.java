package selenium;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


import de.htwg.selenium.HtwgWebDriver;

class GoogleTest {
	
	private static HtwgWebDriver htwgWebDriver;

	@BeforeEach
	void setUpBeforeClass() throws Exception {
		htwgWebDriver = new HtwgWebDriver(); // "--headless"
	}

	@AfterEach
	void tearDownAfterClass() throws Exception {
		htwgWebDriver = null;
	}

	@Test
	void testGoogle() throws Exception {
		htwgWebDriver.get("https://www.google.de");
		htwgWebDriver.sleep(500);
		assertTrue(htwgWebDriver.getTextFromElement("//*[@id=\"hptl\"]/a[1]").contains("�ber Google"));
		htwgWebDriver.input("//*[@name=\"q\"]", "test\n");
		assertTrue(htwgWebDriver.pageContains("Stiftung Warentest"));
		htwgWebDriver.close();
	}
}
