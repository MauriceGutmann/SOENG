package de.htwg.selenium;

import java.util.function.BooleanSupplier;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


public class HtwgWebDriver {
	private WebDriver webDriver;
	
    public HtwgWebDriver() {
    	HtwgWebDriverInitializer wi = new HtwgWebDriverInitializer();
    	this.webDriver = wi.getWebDriver();
    }
    
    public HtwgWebDriver(String arguments) {
    	HtwgWebDriverInitializer wi = new HtwgWebDriverInitializer(arguments);
    	this.webDriver = wi.getWebDriver();    	
    }
	
    
	public void get(String url) {
    	webDriver.get(url);
    }
	
	public void click(String xpath) {
        By by = By.xpath(xpath);
        WebElement webElement = webDriver.findElement(by);
        webElement.click();
	}

	public void input(String xpath, String content) {
        By by = By.xpath(xpath);
        WebElement webElement = webDriver.findElement(by);
        webElement.sendKeys(content);
}

	public String getTextFromElement(String xpath) {
        By by = By.xpath(xpath);
        WebElement webElement = webDriver.findElement(by);
        return webElement.getText();
}
	
	public void close() {
		webDriver.manage().deleteAllCookies();
		webDriver.close();
	}
	
	public void sleep(long milliSeconds) {
		try {
			Thread.sleep(milliSeconds);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public boolean pageContains(String text) {
		return webDriver.getPageSource().contains(text);
	}
	
}
